package com.varsitycollege.st10316986

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView

class Statistics : AppCompatActivity() {
    private lateinit var btnadd : Button
    private lateinit var btnclear : Button
    private lateinit var btnaverage : Button
    private lateinit var btnminmax : Button
    private lateinit var display : TextView
    private lateinit var listview : ListView
    private lateinit var number : EditText

    private val numbersArray = IntArray(10)
    private var enteredNumbersCount = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_statistics)

        btnadd = findViewById(R.id.btnadd)
        btnclear= findViewById(R.id.btnclear)
        btnaverage= findViewById(R.id.btnaverage)
        btnminmax= findViewById(R.id.btnminmax)
        display= findViewById(R.id.display)
        listview= findViewById(R.id.listview)
        number= findViewById(R.id.number)

        val dataList = ArrayList<String>() // to store values
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, dataList)
        listview.adapter = adapter // connects the data to UI

        btnadd.setOnClickListener {
            if (enteredNumbersCount < 10) {
                val inputNumber = number.text.toString().toIntOrNull()
                if (inputNumber != null) {
                    numbersArray[enteredNumbersCount] = inputNumber
                    dataList.add(inputNumber.toString())
                    enteredNumbersCount++
                    adapter.notifyDataSetChanged()
                }
            } else {
                display.text = "Max amount of digits reached"
            }
        }

        btnclear.setOnClickListener {
            dataList.clear()
            enteredNumbersCount = 0
            adapter.notifyDataSetChanged()
            display.text = ""
        }

        btnaverage.setOnClickListener {
            val average = calculateAverage()
            display.text = "Average: $average"
        }

        btnminmax.setOnClickListener {
            if (enteredNumbersCount > 0) {
                var min = numbersArray[0]
                var max = numbersArray[0]

                for (i in 1 until enteredNumbersCount) {
                    min = if (numbersArray[i] < min) numbersArray[i] else min
                    max = if (numbersArray[i] > max) numbersArray[i] else max
                }

                display.text = "Min: $min, Max: $max"
            } else {
                display.text = "No numbers entered."
            }
        }
    }

    //private class function
    private fun calculateAverage(): Double {
        var sum = 0
        for (i in 0 until enteredNumbersCount) {
            sum += numbersArray[i]
        }
        return if (enteredNumbersCount > 0) {
            sum.toDouble() / enteredNumbersCount
        } else {
            0.0
        }
    }
}


//references
//Kotlin Help. (n.d.). Arrays | Kotlin. [online] Available at: https://kotlinlang.org/docs/arrays.html.
//Kotlin Help. (n.d.). Conditions and loops | Kotlin. [online] Available at: https://kotlinlang.org/docs/control-flow.html#if-expression.
//Kotlin Help. (n.d.). Classes | Kotlin. [online] Available at: https://kotlinlang.org/docs/classes.html#companion-objects.
