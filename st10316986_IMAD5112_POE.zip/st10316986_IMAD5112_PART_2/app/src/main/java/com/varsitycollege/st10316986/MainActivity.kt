package com.varsitycollege.st10316986

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private lateinit var btnaddition : Button
    private lateinit var btnsubtraction : Button
    private lateinit var btnmultiplication : Button
    private lateinit var btndivision : Button
    private lateinit var edtnum1 : EditText
    private lateinit var edtnum2 : EditText
    private lateinit var Display : TextView
    private lateinit var btnsquareroot : Button
    private lateinit var btnpower : Button
    private lateinit var btnstatistics : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnaddition = findViewById(R.id.btnaddition)
        btnsubtraction = findViewById(R.id.btnsubtraction)
        btnmultiplication = findViewById(R.id.btnmultiplication)
        btndivision = findViewById(R.id.btndivision)
        edtnum1 = findViewById(R.id.edtnum1)
        edtnum2 = findViewById(R.id.edtnum2)
        Display = findViewById(R.id.Display)
        btnsquareroot = findViewById(R.id.btnsquareroot)
        btnpower = findViewById(R.id.btnpower)
        btnstatistics = findViewById(R.id.btnstatistics)

        btnaddition.setOnClickListener {
            val num1 = edtnum1.text.toString()
            val num2 = edtnum2.text.toString()
            val answer = num1.toInt() + num2.toInt()
            Display.text =  num1.toString() + " + " + num2.toString() + (" = ") + answer.toString()

        }
        btnsubtraction.setOnClickListener{
            val num1 = edtnum1.text.toString()
            val num2 = edtnum2.text.toString()
            val answer = num1.toInt() - num2.toInt()
            Display.text =  num1.toString() + " - " + num2.toString() + (" = ") + answer.toString()
        }
        btnmultiplication.setOnClickListener{

            val num1 = edtnum1.text.toString()
            val num2 = edtnum2.text.toString()
            val answer = num1.toInt() * num2.toInt()
            Display.text =  num1.toString() + " x " + num2.toString() + (" = ") + answer.toString()
        }
        btndivision.setOnClickListener {
            val num1 = edtnum1.text.toString()
            val num2 = edtnum2.text.toString()
            val answer = num1.toInt() / num2.toInt()
            Display.text = num1.toString() + " / " + num2.toString() + (" = ") + answer.toString()
        }

        //PART 2

        btnsquareroot.setOnClickListener {
            val num1 = edtnum1.text.toString().toDouble()

            if (num1 >= 0) {  //if the number is greater than 0 calculate square root else add the imaginary i at the end
                val result = Math.sqrt(num1)
                Display.text = "sqrt($num1) = $result"
            } else {
                val result = Math.sqrt(Math.abs(num1))
                Display.text = "sqrt($num1) = ${result} i"
            }
        }

        btnpower.setOnClickListener {
                val base = edtnum1.text.toString()
                val exponent = edtnum2.text.toString()

                var result = 1
                var count = 0

                while (count < exponent.toInt()) { //while loop is used in a way where it multiplies itself through loops to the number of a power using an incrementation system
                    result *= base.toInt()
                    count++

                }
             Display.text = base + "^" + exponent + " = " + result

            }

        btndivision.setOnClickListener {
            val num1 = edtnum1.text.toString().toDouble()
            val num2 = edtnum2.text.toString().toDouble()

            if (num2 == 0.0) {  //added for division if 0 then display the error
                Display.text = "Error: Division by 0 not allowed"
            } else {
                val result = num1 / num2
                Display.text = result.toString()
            }
        }

        btnstatistics.setOnClickListener {
            val intent = Intent(this, Statistics::class.java)
            startActivity(intent)
        }
    }
}

//reference list
// www.w3schools.com. (n.d.). Kotlin Tutorial. [online] Available at: https://www.w3schools.com/kotlin/index.php.